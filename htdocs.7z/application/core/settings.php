<?php
$GLOBALS['host']='localhost';
$GLOBALS['username']='root';
$GLOBALS['password']='';
$GLOBALS['database']='portfolio';