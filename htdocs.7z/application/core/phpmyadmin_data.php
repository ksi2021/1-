<?php
$GLOBALS['site'] = 'localhost'; // Наименование сайта
$GLOBALS['login'] = 'root'; // Логин
$GLOBALS['password'] = ''; // Пароль
$GLOBALS['lib'] = 'portfolio'; // База данных для подключения
?>
